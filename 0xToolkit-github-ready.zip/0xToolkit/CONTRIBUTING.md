# Contributing to 0xToolkit

1. Fork the repository.
2. Create a focused feature branch.
3. Add tests for new functionality where practical.
4. Keep modules small and reusable.
5. Do not add functionality intended to compromise systems without authorization.
6. Open a pull request with a concise description and test results.
