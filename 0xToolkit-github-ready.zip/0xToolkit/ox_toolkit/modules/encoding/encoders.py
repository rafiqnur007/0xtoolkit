import base64
import binascii
import urllib.parse

def base64_decode(value: str) -> str:
    raw = value.encode()
    raw += b"=" * (-len(raw) % 4)
    return base64.b64decode(raw, validate=False).decode("utf-8", errors="replace")

def base32_decode(value: str) -> str:
    raw = value.encode().upper()
    raw += b"=" * (-len(raw) % 8)
    return base64.b32decode(raw, casefold=True).decode("utf-8", errors="replace")

def base58_decode(value: str) -> bytes:
    alphabet = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    n = 0
    for char in value.encode():
        if char not in alphabet:
            raise ValueError(f"Invalid Base58 character: {chr(char)}")
        n = n * 58 + alphabet.index(char)
    result = n.to_bytes((n.bit_length() + 7) // 8, "big") if n else b""
    pad = len(value) - len(value.lstrip("1"))
    return b"\x00" * pad + result

def hex_decode(value: str) -> str:
    cleaned = value.replace(" ", "").replace(":", "")
    return bytes.fromhex(cleaned).decode("utf-8", errors="replace")

def binary_decode(value: str) -> str:
    bits = "".join(value.split())
    if len(bits) % 8:
        raise ValueError("Binary input length must be a multiple of 8.")
    return bytes(int(bits[i:i+8], 2) for i in range(0, len(bits), 8)).decode("utf-8", errors="replace")

def url_decode(value: str) -> str:
    return urllib.parse.unquote_plus(value)

def url_encode(value: str) -> str:
    return urllib.parse.quote_plus(value)

def auto_decode(value: str) -> list[tuple[str, str]]:
    results = []
    try: results.append(("Base64", base64_decode(value)))
    except Exception: pass
    try: results.append(("Hex", hex_decode(value)))
    except Exception: pass
    try: results.append(("Binary", binary_decode(value)))
    except Exception: pass
    try:
        decoded = url_decode(value)
        if decoded != value:
            results.append(("URL", decoded))
    except Exception: pass
    return results
