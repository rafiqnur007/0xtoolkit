# 0xToolkit

**0xToolkit** is a modular Python toolkit for CTF problem solving, cybersecurity learning, reconnaissance, defensive analysis, digital forensics, encoding/decoding, and small security-automation tasks.

> Use only on systems, files, and targets you own or are explicitly authorized to test.

## Features

- **Encoding:** Base64, Base32, Base58, Hex, Binary, URL encoding
- **Crypto helpers:** Caesar, ROT13, Atbash, XOR, hash identification
- **Forensics:** file type/signature, hashes, strings, entropy, basic EXIF metadata
- **Network:** DNS lookup, reverse DNS, IP validation, TCP connectivity
- **Recon:** robots.txt and HTTP security-header inspection
- **Log analysis:** failed-login extraction and source-IP frequency
- **Web/CTF helpers:** JWT decoding, URL parsing
- **Utilities:** checksum and text transforms
- Clean CLI with Rich output
- Modular architecture designed for adding new scripts

## Quick Start

```bash
git clone https://github.com/rafiqnur007/0xToolkit.git
cd 0xToolkit

python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows
# .venv\Scripts\activate

pip install -r requirements.txt
python -m ox_toolkit --help
```

## Examples

```bash
python -m ox_toolkit crypto decode "SGVsbG8="
python -m ox_toolkit crypto caesar "Khoor" --shift 3
python -m ox_toolkit crypto hashid "5d41402abc4b2a76b9719d911017c592"

python -m ox_toolkit forensic file sample.jpg
python -m ox_toolkit forensic strings sample.bin
python -m ox_toolkit forensic entropy sample.bin
python -m ox_toolkit forensic hash sample.bin --algorithm sha256

python -m ox_toolkit network dns example.com
python -m ox_toolkit network reverse-dns 8.8.8.8
python -m ox_toolkit network tcp 127.0.0.1 80

python -m ox_toolkit recon headers https://example.com
python -m ox_toolkit recon robots https://example.com

python -m ox_toolkit web jwt eyJhbGciOiJub25lIn0.eyJzdWIiOiIxMjMifQ.
python -m ox_toolkit web url "https://example.com/a?id=10"

python -m ox_toolkit logs failed-login auth.log
python -m ox_toolkit logs top-ips access.log
```

## Project layout

```text
0xToolkit/
├── ox_toolkit/
│   ├── cli.py
│   ├── core/
│   └── modules/
│       ├── crypto/
│       ├── encoding/
│       ├── forensic/
│       ├── logs/
│       ├── network/
│       ├── recon/
│       ├── web/
│       └── utils/
├── tests/
├── requirements.txt
├── pyproject.toml
├── LICENSE
├── CONTRIBUTING.md
└── .gitignore
```

## Roadmap

- PCAP helpers
- Steganography helpers
- More CTF encoders/decoders
- IOC extraction
- YARA integration
- PE/ELF analysis helpers
- Plugin system
- JSON output mode
- More unit tests

## License

MIT
