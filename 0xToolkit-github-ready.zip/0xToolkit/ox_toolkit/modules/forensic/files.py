import math
import mimetypes
from collections import Counter
from pathlib import Path

MAGIC = {
    b"\x89PNG\r\n\x1a\n": "PNG image",
    b"\xff\xd8\xff": "JPEG image",
    b"GIF87a": "GIF image",
    b"GIF89a": "GIF image",
    b"PK\x03\x04": "ZIP archive / Office container",
    b"%PDF": "PDF document",
    b"\x7fELF": "ELF executable",
    b"MZ": "PE/DOS executable",
}

def file_type(path: str) -> str:
    data = Path(path).read_bytes()[:16]
    for signature, name in MAGIC.items():
        if data.startswith(signature):
            return name
    return mimetypes.guess_type(path)[0] or "Unknown"

def extract_strings(path: str, min_length: int = 4) -> list[str]:
    data = Path(path).read_bytes()
    strings, current = [], bytearray()
    for b in data:
        if 32 <= b <= 126:
            current.append(b)
        else:
            if len(current) >= min_length:
                strings.append(current.decode("ascii"))
            current.clear()
    if len(current) >= min_length:
        strings.append(current.decode("ascii"))
    return strings

def entropy(path: str) -> float:
    data = Path(path).read_bytes()
    if not data:
        return 0.0
    counts = Counter(data)
    size = len(data)
    return -sum((n/size) * math.log2(n/size) for n in counts.values())
