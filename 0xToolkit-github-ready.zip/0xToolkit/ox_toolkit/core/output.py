from rich.console import Console
from rich.table import Table

console = Console()

def info(message: str) -> None:
    console.print(f"[cyan][*][/cyan] {message}")

def success(message: str) -> None:
    console.print(f"[green][+][/green] {message}")

def error(message: str) -> None:
    console.print(f"[red][-][/red] {message}")

def table(title: str, rows: list[tuple[str, str]]) -> None:
    t = Table(title=title)
    t.add_column("Field", style="cyan")
    t.add_column("Value")
    for key, value in rows:
        t.add_row(str(key), str(value))
    console.print(t)
