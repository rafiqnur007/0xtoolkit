import re
from collections import Counter

IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")

def top_ips(path: str, limit: int = 10) -> list[tuple[str, int]]:
    counter = Counter()
    with open(path, "r", errors="replace") as f:
        for line in f:
            counter.update(IP_RE.findall(line))
    return counter.most_common(limit)

def failed_logins(path: str) -> list[str]:
    hits = []
    keywords = ("failed password", "authentication failure", "login failed", "invalid user")
    with open(path, "r", errors="replace") as f:
        for line in f:
            low = line.lower()
            if any(k in low for k in keywords):
                hits.append(line.rstrip())
    return hits
