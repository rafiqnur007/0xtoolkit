from ox_toolkit.modules.crypto.classical import caesar, rot13, atbash, xor_bytes
from ox_toolkit.modules.encoding.encoders import base64_decode, hex_decode
from ox_toolkit.modules.crypto.hashes import identify_hash

def test_caesar():
    assert caesar("Khoor", -3) == "Hello"

def test_rot13():
    assert rot13("Hello") == "Uryyb"

def test_atbash():
    assert atbash("abc") == "zyx"

def test_xor():
    assert xor_bytes(b"ABC", b"\x01") == b"@CB"

def test_base64():
    assert base64_decode("SGVsbG8=") == "Hello"

def test_hex():
    assert hex_decode("48656c6c6f") == "Hello"

def test_hashid():
    assert "MD5" in identify_hash("5d41402abc4b2a76b9719d911017c592")
