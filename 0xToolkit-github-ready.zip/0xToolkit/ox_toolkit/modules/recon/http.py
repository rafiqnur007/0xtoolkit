import requests

def headers(url: str) -> dict[str, str]:
    response = requests.get(url, timeout=10, allow_redirects=True)
    return dict(response.headers)

def robots(url: str) -> tuple[int, str]:
    target = url.rstrip("/") + "/robots.txt"
    response = requests.get(target, timeout=10)
    return response.status_code, response.text[:20000]
