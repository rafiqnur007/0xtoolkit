import ipaddress
import socket

def dns_lookup(host: str) -> list[str]:
    return sorted({item[4][0] for item in socket.getaddrinfo(host, None)})

def reverse_dns(ip: str) -> str:
    return socket.gethostbyaddr(ip)[0]

def valid_ip(value: str) -> bool:
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False

def tcp_connect(host: str, port: int, timeout: float = 2.0) -> tuple[bool, str]:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True, "Connection succeeded"
    except OSError as exc:
        return False, str(exc)
