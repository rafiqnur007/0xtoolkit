import base64
import json
import urllib.parse

def decode_jwt(token: str) -> tuple[dict, dict]:
    parts = token.split(".")
    if len(parts) != 3:
        raise ValueError("JWT must contain three dot-separated parts.")
    def dec(part: str) -> dict:
        raw = part.encode() + b"=" * (-len(part) % 4)
        return json.loads(base64.urlsafe_b64decode(raw).decode())
    return dec(parts[0]), dec(parts[1])

def parse_url(url: str) -> dict:
    p = urllib.parse.urlparse(url)
    return {
        "scheme": p.scheme,
        "host": p.hostname or "",
        "port": str(p.port or ""),
        "path": p.path,
        "query": p.query,
        "fragment": p.fragment,
    }
