import hashlib
import re

PATTERNS = {
    "MD5": r"^[a-fA-F0-9]{32}$",
    "SHA1": r"^[a-fA-F0-9]{40}$",
    "SHA256": r"^[a-fA-F0-9]{64}$",
    "SHA512": r"^[a-fA-F0-9]{128}$",
}

def identify_hash(value: str) -> list[str]:
    return [name for name, pattern in PATTERNS.items() if re.fullmatch(pattern, value.strip())]

def digest_file(path: str, algorithm: str = "sha256", chunk_size: int = 1024 * 1024) -> str:
    algorithm = algorithm.lower()
    if algorithm not in hashlib.algorithms_available:
        raise ValueError(f"Unsupported algorithm: {algorithm}")
    h = hashlib.new(algorithm)
    with open(path, "rb") as f:
        while chunk := f.read(chunk_size):
            h.update(chunk)
    return h.hexdigest()
