import json
from pathlib import Path
import typer
from rich import print as rprint
from rich.console import Console
from rich.table import Table

from .modules.encoding.encoders import (
    base64_decode, base32_decode, base58_decode, hex_decode,
    binary_decode, url_decode, url_encode, auto_decode
)
from .modules.crypto.classical import caesar, rot13, atbash, xor_bytes
from .modules.crypto.hashes import identify_hash, digest_file
from .modules.forensic.files import file_type, extract_strings, entropy
from .modules.network.net import dns_lookup, reverse_dns, tcp_connect, valid_ip
from .modules.recon.http import headers, robots
from .modules.web.helpers import decode_jwt, parse_url
from .modules.logs.analyzer import top_ips, failed_logins

app = typer.Typer(help="0xToolkit — CTF & Cybersecurity Utility Toolkit")
crypto = typer.Typer(help="Cryptography and classical cipher helpers.")
encoding = typer.Typer(help="Encoding/decoding utilities.")
forensic = typer.Typer(help="Digital forensics helpers.")
network = typer.Typer(help="Network utilities.")
recon = typer.Typer(help="Reconnaissance utilities.")
web = typer.Typer(help="Web/CTF helpers.")
logs = typer.Typer(help="Log analysis helpers.")

for group, name in [
    (crypto, "crypto"), (encoding, "encoding"), (forensic, "forensic"),
    (network, "network"), (recon, "recon"), (web, "web"), (logs, "logs")
]:
    app.add_typer(group, name=name)

@app.callback()
def root():
    """0xToolkit: modular scripts for CTFs, DFIR, recon and security automation."""

@encoding.command("decode")
def encoding_decode(value: str):
    """Try common decoders against a value."""
    results = auto_decode(value)
    if not results:
        rprint("[yellow]No supported encoding confidently decoded the input.[/yellow]")
        return
    for name, result in results:
        rprint(f"[cyan]{name}:[/cyan] {result}")

@encoding.command("base64")
def enc_base64(value: str):
    rprint(base64_decode(value))

@encoding.command("base32")
def enc_base32(value: str):
    rprint(base32_decode(value))

@encoding.command("base58")
def enc_base58(value: str):
    rprint(base58_decode(value).decode("utf-8", errors="replace"))

@encoding.command("hex")
def enc_hex(value: str):
    rprint(hex_decode(value))

@encoding.command("binary")
def enc_binary(value: str):
    rprint(binary_decode(value))

@encoding.command("url")
def enc_url(value: str, decode: bool = True):
    rprint(url_decode(value) if decode else url_encode(value))

@crypto.command("caesar")
def crypto_caesar(value: str, shift: int = typer.Option(..., "--shift", "-s")):
    rprint(caesar(value, shift))

@crypto.command("rot13")
def crypto_rot13(value: str):
    rprint(rot13(value))

@crypto.command("atbash")
def crypto_atbash(value: str):
    rprint(atbash(value))

@crypto.command("xor")
def crypto_xor(value: str, key: str):
    result = xor_bytes(value.encode(), key.encode())
    rprint(result.decode("utf-8", errors="replace"))
    rprint(f"[dim]hex: {result.hex()}[/dim]")

@crypto.command("hashid")
def crypto_hashid(value: str):
    matches = identify_hash(value)
    rprint(", ".join(matches) if matches else "Unknown/unsupported hash format")

@forensic.command("file")
def forensic_file(path: str):
    p = Path(path)
    if not p.is_file():
        raise typer.BadParameter("File does not exist.")
    table = Table(title="File Analysis")
    table.add_column("Property")
    table.add_column("Value")
    table.add_row("Path", str(p))
    table.add_row("Size", f"{p.stat().st_size} bytes")
    table.add_row("Type", file_type(path))
    table.add_row("Entropy", f"{entropy(path):.4f}")
    table.add_row("SHA256", digest_file(path, "sha256"))
    Console().print(table)

@forensic.command("strings")
def forensic_strings(path: str, min_length: int = 4):
    for line in extract_strings(path, min_length):
        print(line)

@forensic.command("entropy")
def forensic_entropy(path: str):
    rprint(f"{entropy(path):.6f}")

@forensic.command("hash")
def forensic_hash(path: str, algorithm: str = "sha256"):
    rprint(digest_file(path, algorithm))

@network.command("dns")
def network_dns(host: str):
    for ip in dns_lookup(host):
        rprint(ip)

@network.command("reverse-dns")
def network_reverse(ip: str):
    if not valid_ip(ip):
        raise typer.BadParameter("Invalid IP address.")
    rprint(reverse_dns(ip))

@network.command("tcp")
def network_tcp(host: str, port: int, timeout: float = 2.0):
    ok, message = tcp_connect(host, port, timeout)
    rprint(f"[green]OPEN/REACHABLE[/green] {message}" if ok else f"[red]FAILED[/red] {message}")

@recon.command("headers")
def recon_headers(url: str):
    for key, value in headers(url).items():
        rprint(f"[cyan]{key}:[/cyan] {value}")

@recon.command("robots")
def recon_robots(url: str):
    status, body = robots(url)
    rprint(f"[cyan]HTTP {status}[/cyan]")
    rprint(body)

@web.command("jwt")
def web_jwt(token: str):
    header, payload = decode_jwt(token)
    rprint("[bold]Header[/bold]")
    rprint(json.dumps(header, indent=2))
    rprint("[bold]Payload[/bold]")
    rprint(json.dumps(payload, indent=2))

@web.command("url")
def web_url(url: str):
    for key, value in parse_url(url).items():
        rprint(f"[cyan]{key}:[/cyan] {value}")

@logs.command("top-ips")
def logs_top_ips(path: str, limit: int = 10):
    for ip, count in top_ips(path, limit):
        rprint(f"{ip:>16}  {count}")

@logs.command("failed-login")
def logs_failed_login(path: str):
    hits = failed_logins(path)
    rprint(f"[cyan]Matches: {len(hits)}[/cyan]")
    for line in hits:
        print(line)
